export class VrstaModel {
  constructor(public kratica: string, public opis?: string) {}
}
