export class GradModel {
  constructor(public naziv: string, public postanskiBroj?: number) {}
}
