export class MockRecenzijaService {}
