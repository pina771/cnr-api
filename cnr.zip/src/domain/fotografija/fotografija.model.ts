export class FotografijaModel {
  constructor(public url: string) {}
}
