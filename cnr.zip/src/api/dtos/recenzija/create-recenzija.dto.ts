export class CreateRecenzijaDTO {
  tekst: string;
  naslov: string;
}
