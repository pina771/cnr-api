export class UpdateObjektDTO {
  public naziv?: string;
  public adresa?: string;
  public kontaktBroj?: string;
  public grad?: string;
  public vrsta?: string;

  public radnoVrijeme?: string;
  public pogodnosti?: string[];
}
