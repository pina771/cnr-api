export class PogodnostModel {
  constructor(public naziv: string, public opis: string) {}
}
